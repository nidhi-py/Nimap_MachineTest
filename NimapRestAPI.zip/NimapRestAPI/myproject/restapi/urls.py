from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('CreateClient/',views.Create_Client.as_view(),name="CreateClient"),
    path('GetClientList/',views.Client_List.as_view()),
    path('DelClient/<int:pk>',views.Delete_ClientList.as_view()),
    path('UpdateClient/<int:pk>',views.Edit_ClientList.as_view()),
    path('Createuser/',views.Create_User.as_view()),
    path('GetUserList/',views.User_List.as_view()),
    path('DelUser/<str:pk>',views.Delete_UserList.as_view()),
    path('UpdateUser/<str:pk>',views.Edit_UserList.as_view()),
    path('CreateProject/',views.Create_Project.as_view()),
    path('GetProjectList/',views.Project_List.as_view()),
    path('DelProject/<int:pk>',views.Delete_ProjectList.as_view()),
    path('UpdateProject/<int:pk>',views.Edit_ProjectList.as_view()),

]