from restapi.models import Client, Project, User
from rest_framework import serializers

class Client_serializer(serializers.ModelSerializer):
    class Meta: 
        model=Client
        fields='__all__'

class Project_serializer(serializers.ModelSerializer):
    class Meta:
        model=Project
        fields='__all__'

class User_serializer(serializers.ModelSerializer):
    class Meta:
        model=User
        fields=["username"]