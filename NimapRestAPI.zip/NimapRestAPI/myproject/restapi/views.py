from django.shortcuts import render
from restapi.serializer import Client_serializer, Project_serializer, User_serializer
from restapi.models import Client, Project, User
from rest_framework import generics

# Create your views here.

class Create_User(generics.CreateAPIView):
    queryset=User.objects.all()              # we store all the objects here
    serializer_class=User_serializer

class User_List(generics.ListAPIView):
    queryset=User.objects.all()
    serializer_class=User_serializer

class Delete_UserList(generics.RetrieveDestroyAPIView):
    queryset=User.objects.all()
    serializer_class=User_serializer

class Edit_UserList(generics.RetrieveUpdateDestroyAPIView):
    queryset=User.objects.all()
    serializer_class=User_serializer

#CLient

class Create_Client(generics.CreateAPIView):
    queryset=Client.objects.all()              
    serializer_class=Client_serializer

class Client_List(generics.ListAPIView):
    queryset=Client.objects.all()
    serializer_class=Client_serializer

class Delete_ClientList(generics.RetrieveDestroyAPIView):
    queryset=Client.objects.all()
    serializer_class=Client_serializer

class Edit_ClientList(generics.RetrieveUpdateDestroyAPIView):
    queryset=Client.objects.all()
    serializer_class=Client_serializer

#Project

class Create_Project(generics.CreateAPIView):
    queryset=Project.objects.all()              
    serializer_class=Project_serializer

class Project_List(generics.ListAPIView):
    queryset=Project.objects.all()
    serializer_class=Project_serializer

class Delete_ProjectList(generics.RetrieveDestroyAPIView):
    queryset=Project.objects.all()
    serializer_class=Project_serializer

class Edit_ProjectList(generics.RetrieveUpdateDestroyAPIView):
    queryset=Project.objects.all()
    serializer_class=Project_serializer

